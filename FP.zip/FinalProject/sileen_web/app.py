from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a random secret key

# Database Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',        # Change as needed
    'password': 'Anwar@2004',        # Change as needed (suggested: Anwar@2004 based on history)
    'database': 'SileenSystem'
}

def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Simple hash check (In production, use bcrypt)
        # The schema uses password_hash VARCHAR(255)
        # We'll assume simple SHA256 for this demo or plain text if not specified, 
        # but let's try to be consistent with a "Log in" feature.
        # hash_object = hashlib.sha256(password.encode())
        # password_hash = hash_object.hexdigest()
        
        # For compatibility with existing manual inserts (like 'hash_saleh_123'), 
        # we might need to know the hashing algorithm. 
        # For now, I'll just check against the database assuming the user handles hashing 
        # or I will implement a basic check.
        # Let's assume plain text for the 'demo' or a specific hash.
        # Given the inserts 'hash_saleh_123', it looks like manual strings.
        
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user_accounts WHERE username = %s", (username,))
            user = cursor.fetchone()
            conn.close()
            
            if user:
                # verify password (placeholder logic)
                # If you want to use real hashing:
                # if user['password_hash'] == hashlib.sha256(password.encode()).hexdigest():
                if user['password_hash'] == password: # Plain comparison for now as we don't know the hash algo used in DB
                    session['user_id'] = user['user_id']
                    session['role'] = user['role']
                    flash('Logged in successfully!', 'success')
                    if user['role'] == 'Admin':
                        return redirect(url_for('admin_dashboard'))
                    elif user['role'] == 'Customer':
                        return redirect(url_for('customer_home'))
                    else:
                        return redirect(url_for('home'))
                else:
                     flash('Invalid password', 'danger')
            else:
                flash('User not found', 'danger')
        else:
             flash('Database connection failed', 'danger')
             
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        name = request.form['name']
        
        # Logic: 
        # 1. Create Customer
        # 2. Create User Account
        # 3. Link them
        
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                
                # Check if username exists
                cursor.execute("SELECT user_id FROM user_accounts WHERE username = %s", (username,))
                if cursor.fetchone():
                    flash('Username already exists', 'warning')
                    conn.close()
                    return redirect(url_for('signup'))

                # 1. Insert Customer
                cursor.execute("INSERT INTO customers (name, email) VALUES (%s, %s)", (name, email))
                customer_id = cursor.lastrowid
                
                # 2. Insert User Account (Role = Customer)
                # simple hash or plain for demo
                # password_hash = hashlib.sha256(password.encode()).hexdigest()
                password_hash = password 
                
                cursor.execute("INSERT INTO user_accounts (username, password_hash, role) VALUES (%s, %s, 'Customer')", 
                               (username, password_hash))
                user_id = cursor.lastrowid
                
                # 3. Link
                cursor.execute("INSERT INTO customer_user_accounts (customer_id, user_id) VALUES (%s, %s)", 
                               (customer_id, user_id))
                
                conn.commit()
                conn.close()
                flash('Account created successfully! Please login.', 'success')
                return redirect(url_for('login'))
            except Error as e:
                flash(f'Error: {e}', 'danger')
        else:
            flash('Database connection failed', 'danger')

    return render_template('signup.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session.get('role') != 'Admin':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    return render_template('admin/dashboard.html')

@app.route('/customer/home')
def customer_home():
    if 'user_id' not in session or session.get('role') != 'Customer':
        flash('Please login to access this page', 'warning')
        return redirect(url_for('login'))
    
    # Fetch categories for customer home page
    conn = get_db_connection()
    categories_list = []
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT category_id, name, description, image_path 
                FROM categories 
                ORDER BY name
            """)
            categories_list = cursor.fetchall()
        except Error as e:
            flash(f'Error fetching categories: {e}', 'danger')
        finally:
            conn.close()
    
    return render_template('customer/home.html', categories=categories_list)

@app.route('/products')
def products():
    """Browse Categories page"""
    conn = get_db_connection()
    categories_list = []
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT category_id, name, description, image_path 
                FROM categories 
                ORDER BY name
            """)
            categories_list = cursor.fetchall()
        except Error as e:
            flash(f'Error fetching categories: {e}', 'danger')
        finally:
            conn.close()
    else:
        flash('Database connection failed', 'danger')
    
    return render_template('products.html', categories=categories_list)

@app.route('/category/<int:category_id>')
def category_products(category_id):
    """Display products within a specific category"""
    conn = get_db_connection()
    category = None
    products_list = []
    
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            
            # Get category info
            cursor.execute("""
                SELECT category_id, name, description, image_path 
                FROM categories 
                WHERE category_id = %s
            """, (category_id,))
            category = cursor.fetchone()
            
            # Get products in this category
            cursor.execute("""
                SELECT item_id, name, description, unit_price, stock_quantity, image_path 
                FROM stock_items 
                WHERE category_id = %s
                ORDER BY name
            """, (category_id,))
            products_list = cursor.fetchall()
            
        except Error as e:
            flash(f'Error fetching products: {e}', 'danger')
        finally:
            conn.close()
    else:
        flash('Database connection failed', 'danger')
    
    if not category:
        flash('Category not found', 'warning')
        return redirect(url_for('products'))
    
    return render_template('category_products.html', category=category, products=products_list)

@app.route('/product/<int:item_id>')
def product_details(item_id):
    """Display product details page - shows name, description, price, category, warehouse"""
    conn = get_db_connection()
    product = None
    
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            
            # Get product with category and warehouse info using JOIN
            cursor.execute("""
                SELECT 
                    s.item_id,
                    s.name,
                    s.description,
                    s.unit_price,
                    s.stock_quantity,
                    s.image_path,
                    s.import_date,
                    c.category_id,
                    c.name AS category_name,
                    c.description AS category_description,
                    w.warehouse_id,
                    w.name AS warehouse_name,
                    w.location AS warehouse_location
                FROM stock_items s
                LEFT JOIN categories c ON s.category_id = c.category_id
                LEFT JOIN warehouses w ON s.warehouse_id = w.warehouse_id
                WHERE s.item_id = %s
            """, (item_id,))
            product = cursor.fetchone()
            
        except Error as e:
            flash(f'Error fetching product details: {e}', 'danger')
        finally:
            conn.close()
    else:
        flash('Database connection failed', 'danger')
    
    if not product:
        flash('Product not found', 'warning')
        return redirect(url_for('products'))
    
    return render_template('product_details.html', product=product)

# --- Shopping Cart Routes (Session Based) ---

@app.route('/add_to_cart/<int:item_id>', methods=['POST'])
def add_to_cart(item_id):
    """Add item to session cart"""
    if 'user_id' not in session:
        flash('Please login to add items to cart', 'warning')
        return redirect(url_for('login'))
        
    quantity = int(request.form.get('quantity', 1))
    
    # Initialize cart if not exists
    if 'cart' not in session:
        session['cart'] = {}
    
    # Check if item exists in DB (optional but good practice)
    # ... logic skipped for brevity, relying on user interaction flow
    
    cart = session['cart']
    # If item already in cart, increment quantity
    if str(item_id) in cart:
        cart[str(item_id)] += quantity
    else:
        cart[str(item_id)] = quantity
    
    session.modified = True
    flash('Item added to cart successfully!', 'success')
    return redirect(request.referrer or url_for('products'))

@app.route('/cart')
def view_cart():
    """Display shopping cart contents"""
    if 'user_id' not in session:
        flash('Please login to view cart', 'warning')
        return redirect(url_for('login'))
    
    cart = session.get('cart', {})
    cart_items = []
    total_price = 0
    
    if cart:
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                # Fetch details for all items in cart
                item_ids = list(cart.keys())
                if item_ids:
                    format_strings = ','.join(['%s'] * len(item_ids))
                    cursor.execute(f"SELECT item_id, name, unit_price, image_path FROM stock_items WHERE item_id IN ({format_strings})", tuple(item_ids))
                    items = cursor.fetchall()
                    
                    for item in items:
                        item_id = str(item['item_id'])
                        quantity = cart.get(item_id, 0)
                        subtotal = item['unit_price'] * quantity
                        total_price += subtotal
                        
                        cart_items.append({
                            'item_id': item['item_id'],
                            'name': item['name'],
                            'unit_price': item['unit_price'],
                            'image_path': item['image_path'],
                            'quantity': quantity,
                            'subtotal': subtotal
                        })
            except Error as e:
                flash(f'Error loading cart: {e}', 'danger')
            finally:
                conn.close()
    
    return render_template('cart.html', cart_items=cart_items, total=total_price)

@app.route('/update_cart/<int:item_id>', methods=['POST'])
def update_cart(item_id):
    """Update item quantity or remove from cart"""
    action = request.form.get('action')
    
    if 'cart' in session:
        cart = session['cart']
        item_str = str(item_id)
        
        if item_str in cart:
            if action == 'increase':
                cart[item_str] += 1
            elif action == 'decrease':
                if cart[item_str] > 1:
                    cart[item_str] -= 1
                else:
                    del cart[item_str] # Remove if quantity becomes 0
            elif action == 'remove':
                del cart[item_str]
                
            session.modified = True
            
    return redirect(url_for('view_cart'))

@app.route('/clear_cart')
def clear_cart():
    """Empty the entire cart"""
    session.pop('cart', None)
    flash('Cart cleared.', 'info')
    return redirect(url_for('view_cart'))

@app.route('/checkout', methods=['POST'])
def checkout():
    """Process Checkout: 5 Database Steps"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    cart = session.get('cart', {})
    if not cart:
        flash('Cart is empty', 'warning')
        return redirect(url_for('products'))

    user_id = session['user_id']
    
    conn = get_db_connection()
    if not conn:
        flash('Database connection failed', 'danger')
        return redirect(url_for('view_cart'))
        
    try:
        cursor = conn.cursor(dictionary=True)
        conn.start_transaction()
        
        # Get Customer ID from User ID
        cursor.execute("SELECT customer_id FROM customer_user_accounts WHERE user_id = %s", (user_id,))
        customer_res = cursor.fetchone()
        
        if not customer_res:
            # Fallback if specific customer link missing (should not happen in prod logic)
            # For this demo, let's assume customer_id 1 if not found or error out
            flash('Customer profile not linked. Please contact support.', 'danger')
            return redirect(url_for('view_cart'))
            
        customer_id = customer_res['customer_id']
        branch_id = 1 # Default Main Branch
        staff_id = 1  # Default Online Sales Staff
        
        # Calculate Total
        item_ids = list(cart.keys())
        format_strings = ','.join(['%s'] * len(item_ids))
        cursor.execute(f"SELECT item_id, unit_price, warehouse_id FROM stock_items WHERE item_id IN ({format_strings})", tuple(item_ids))
        db_items = {str(item['item_id']): item for item in cursor.fetchall()}
        
        total_amount = 0
        for item_id, qty in cart.items():
            if str(item_id) in db_items:
                total_amount += db_items[str(item_id)]['unit_price'] * qty

        # 1️⃣ Create Sales Order
        cursor.execute("""
            INSERT INTO sales_orders (customer_id, branch_id, staff_id, status, total_amount)
            VALUES (%s, %s, %s, 'Completed', %s)
        """, (customer_id, branch_id, staff_id, total_amount))
        sales_order_id = cursor.lastrowid
        
        # Process Items
        for item_id, qty in cart.items():
            item_data = db_items.get(str(item_id))
            if item_data:
                unit_price = item_data['unit_price']
                warehouse_id = item_data['warehouse_id'] or 1 # Default warehouse if null
                
                # 2️⃣ Insert Sale Item
                cursor.execute("""
                    INSERT INTO sale_items (sales_order_id, item_id, quantity, unit_price, discount)
                    VALUES (%s, %s, %s, %s, 0.00)
                """, (sales_order_id, item_id, qty, unit_price))
                
                # 3️⃣ Update Stock
                cursor.execute("""
                    UPDATE stock_items 
                    SET stock_quantity = stock_quantity - %s 
                    WHERE item_id = %s
                """, (qty, item_id))
                
                # 4️⃣ Insert Stock Movement
                cursor.execute("""
                    INSERT INTO stock_movements 
                    (item_id, warehouse_id, movement_type, quantity, reference_type, reference_id)
                    VALUES (%s, %s, 'OUT', %s, 'Sale', %s)
                """, (item_id, warehouse_id, qty, sales_order_id))

        # 5️⃣ Create Invoice
        tax = total_amount * 0.15 # 15% Tax example
        cursor.execute("""
            INSERT INTO invoices (sales_order_id, amount, tax, payment_status)
            VALUES (%s, %s, %s, 'Paid')
        """, (sales_order_id, total_amount, tax))
        
        conn.commit()
        session.pop('cart', None) # Clear cart
        flash(f'Order #{sales_order_id} placed successfully!', 'success')
        return redirect(url_for('order_history'))
        
    except Error as e:
        conn.rollback()
        flash(f'Transaction failed: {e}', 'danger')
        return redirect(url_for('view_cart'))
    finally:
        conn.close()

@app.route('/orders')
def order_history():
    """Display Customer Order History"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    user_id = session['user_id']
    
    conn = get_db_connection()
    orders = []
    
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            
            # Get Customer ID
            cursor.execute("SELECT customer_id FROM customer_user_accounts WHERE user_id = %s", (user_id,))
            customer_res = cursor.fetchone()
            
            if customer_res:
                customer_id = customer_res['customer_id']
                
                # Get Orders with Invoice info
                cursor.execute("""
                    SELECT so.sales_order_id, so.order_date, so.status, so.total_amount, i.payment_status
                    FROM sales_orders so
                    LEFT JOIN invoices i ON so.sales_order_id = i.sales_order_id
                    WHERE so.customer_id = %s
                    ORDER BY so.order_date DESC
                """, (customer_id,))
                orders = cursor.fetchall()
                
                # Get Items for each order (Inefficient N+1 but simple for now)
                for order in orders:
                    cursor.execute("""
                        SELECT si.quantity, si.unit_price, s.name, s.image_path
                        FROM sale_items si
                        JOIN stock_items s ON si.item_id = s.item_id
                        WHERE si.sales_order_id = %s
                    """, (order['sales_order_id'],))
                    order['items'] = cursor.fetchall()
            
        except Error as e:
            flash(f'Error fetching orders: {e}', 'danger')
        finally:
            conn.close()
            
    return render_template('orders.html', orders=orders)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
