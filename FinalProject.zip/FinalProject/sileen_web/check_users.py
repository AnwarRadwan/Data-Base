
import mysql.connector
from mysql.connector import Error

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '0000',
    'database': 'SileenSystem'
}

try:
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, username, password_hash, role FROM user_accounts;")
    users = cursor.fetchall()
    print("Users in DB:")
    for user in users:
        print(user)
    conn.close()
except Error as e:
    print(f"Error: {e}")
