# Sileen Boutique Web Application

## How to Run
1. Ensure your MySQL server is running.
2. Edit `app.py` line 10-15 to match your MySQL username and password (default set to 'root' and empty password, or 'Anwar@2004').
3. Run the application:
   ```bash
   python app.py
   ```
4. Open your browser at `http://127.0.0.1:5000`.

## Database
Ensure you have run the `FinaPhase.sql` script to create the `SileenSystem` database.
This app uses `user_accounts`, `customers` tables.
