from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a random secret key

# Database Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',        # Change as needed
    'password': '0000',        # Change as needed (suggested: Anwar@2004 based on history)
    'database': 'SileenSystem'
}

def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Simple hash check (In production, use bcrypt)
        # The schema uses password_hash VARCHAR(255)
        # We'll assume simple SHA256 for this demo or plain text if not specified, 
        # but let's try to be consistent with a "Log in" feature.
        # hash_object = hashlib.sha256(password.encode())
        # password_hash = hash_object.hexdigest()
        
        # For compatibility with existing manual inserts (like 'hash_saleh_123'), 
        # we might need to know the hashing algorithm. 
        # For now, I'll just check against the database assuming the user handles hashing 
        # or I will implement a basic check.
        # Let's assume plain text for the 'demo' or a specific hash.
        # Given the inserts 'hash_saleh_123', it looks like manual strings.
        
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user_accounts WHERE username = %s", (username,))
            user = cursor.fetchone()
            conn.close()
            
            if user:
                # verify password (placeholder logic)
                # If you want to use real hashing:
                # if user['password_hash'] == hashlib.sha256(password.encode()).hexdigest():
                if user['password_hash'] == password: # Plain comparison for now as we don't know the hash algo used in DB
                    session['user_id'] = user['user_id']
                    session['role'] = user['role']
                    flash('Logged in successfully!', 'success')
                    if user['role'] == 'Admin':
                        return redirect(url_for('admin_dashboard'))
                    elif user['role'] == 'Customer':
                        return redirect(url_for('customer_home'))
                    else:
                        return redirect(url_for('home'))
                else:
                     flash('Invalid password', 'danger')
            else:
                flash('User not found', 'danger')
        else:
             flash('Database connection failed', 'danger')
             
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        name = request.form['name']
        
        # Logic: 
        # 1. Create Customer
        # 2. Create User Account
        # 3. Link them
        
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                
                # Check if username exists
                cursor.execute("SELECT user_id FROM user_accounts WHERE username = %s", (username,))
                if cursor.fetchone():
                    flash('Username already exists', 'warning')
                    conn.close()
                    return redirect(url_for('signup'))

                # 1. Insert Customer
                cursor.execute("INSERT INTO customers (name, email) VALUES (%s, %s)", (name, email))
                customer_id = cursor.lastrowid
                
                # 2. Insert User Account (Role = Customer)
                # simple hash or plain for demo
                # password_hash = hashlib.sha256(password.encode()).hexdigest()
                password_hash = password 
                
                cursor.execute("INSERT INTO user_accounts (username, password_hash, role) VALUES (%s, %s, 'Customer')", 
                               (username, password_hash))
                user_id = cursor.lastrowid
                
                # 3. Link
                cursor.execute("INSERT INTO customer_user_accounts (customer_id, user_id) VALUES (%s, %s)", 
                               (customer_id, user_id))
                
                conn.commit()
                conn.close()
                flash('Account created successfully! Please login.', 'success')
                return redirect(url_for('login'))
            except Error as e:
                flash(f'Error: {e}', 'danger')
        else:
            flash('Database connection failed', 'danger')

    return render_template('signup.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session.get('role') != 'Admin':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    return render_template('admin/dashboard.html')

@app.route('/customer/home')
def customer_home():
    if 'user_id' not in session or session.get('role') != 'Customer':
        flash('Please login to access this page', 'warning')
        return redirect(url_for('login'))
    return render_template('customer/home.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
