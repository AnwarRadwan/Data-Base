
import mysql.connector
from mysql.connector import Error

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '0000',
    'database': 'SileenSystem'
}

try:
    print("Attempting to connect...")
    conn = mysql.connector.connect(**db_config)
    if conn.is_connected():
        print("Connection established successfully.")
        
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES;")
        tables = cursor.fetchall()
        print("Tables in database:")
        for table in tables:
            print(table)
            
        conn.close()
except Error as e:
    print(f"Error connecting to MySQL: {e}")
