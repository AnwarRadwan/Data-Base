-- =========================
-- Create DB + Use
-- =========================
CREATE DATABASE IF NOT EXISTS SileenSystem;
USE SileenSystem;

-- =========================
-- Reset (Drop)
-- =========================
SET FOREIGN_KEY_CHECKS = 0;

-- Drop tables (children -> parents)
DROP TABLE IF EXISTS customer_user_accounts;
DROP TABLE IF EXISTS returns;
DROP TABLE IF EXISTS sale_items;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS sales_orders;

DROP TABLE IF EXISTS stock_movements;
DROP TABLE IF EXISTS purchase_order_items;
DROP TABLE IF EXISTS purchase_orders;

DROP TABLE IF EXISTS stock_items;     -- boutique items
DROP TABLE IF EXISTS items;           -- original items
DROP TABLE IF EXISTS categories;

DROP TABLE IF EXISTS warehouses;
DROP TABLE IF EXISTS customers;

DROP TABLE IF EXISTS user_accounts;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS managers;
DROP TABLE IF EXISTS branches;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================
-- (A) Original System Tables
-- =========================

-- =========================
-- 1) Branches
-- =========================
CREATE TABLE branches (
  branch_id       INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100) NOT NULL,
  location        VARCHAR(200) NOT NULL,
  contact_person  VARCHAR(100)
);

-- =========================
-- 2) Warehouses
-- =========================
CREATE TABLE warehouses (
  warehouse_id  INT AUTO_INCREMENT PRIMARY KEY,
  branch_id     INT NOT NULL,
  name          VARCHAR(100) NOT NULL,
  location      VARCHAR(200) NOT NULL,
  capacity      INT,
  FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- 3) Managers
-- =========================
CREATE TABLE managers (
  manager_id    INT AUTO_INCREMENT PRIMARY KEY,
  branch_id     INT NOT NULL,
  name          VARCHAR(100) NOT NULL,
  role          VARCHAR(50),
  email         VARCHAR(150),
  phone_number  VARCHAR(30),
  FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- 4) Staff
-- =========================
CREATE TABLE staff (
  staff_id     INT AUTO_INCREMENT PRIMARY KEY,
  branch_id    INT NOT NULL,
  manager_id   INT,
  name         VARCHAR(100) NOT NULL,
  role         VARCHAR(50),
  phone        VARCHAR(30),
  email        VARCHAR(150),
  FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION,
  FOREIGN KEY (manager_id) REFERENCES managers(manager_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 5) User Accounts (Admin / Customer)
-- =========================
CREATE TABLE user_accounts (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  staff_id      INT,
  username      VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(20) NOT NULL,  -- Admin / Customer
  FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 6) Purchase Orders (NO warehouse_id)
-- =========================
CREATE TABLE purchase_orders (
  purchase_order_id  INT AUTO_INCREMENT PRIMARY KEY,
  staff_id           INT,
  order_date         DATE NOT NULL,
  total_amount       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  status             VARCHAR(30) NOT NULL,
  FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 7) Categories
-- =========================
CREATE TABLE categories (
  category_id   INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  description   VARCHAR(255)
);

-- =========================
-- 8) Items (Original)
-- =========================
CREATE TABLE items (
  item_id        INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(150) NOT NULL,
  unit_price     DECIMAL(12,2) NOT NULL,
  stock_quantity INT NOT NULL DEFAULT 0,
  category_id    INT,
  FOREIGN KEY (category_id) REFERENCES categories(category_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 9) Purchase Order Items (Ternary)
-- =========================
CREATE TABLE purchase_order_items (
  purchase_order_id INT NOT NULL,
  item_id           INT NOT NULL,
  warehouse_id      INT NOT NULL,
  quantity          INT NOT NULL,
  unit_price        DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (purchase_order_id, item_id, warehouse_id),
  FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(purchase_order_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES items(item_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- 10) Stock Movements
-- =========================
CREATE TABLE stock_movements (
  movement_id     INT AUTO_INCREMENT PRIMARY KEY,
  item_id         INT NOT NULL,
  warehouse_id    INT NOT NULL,
  movement_type   VARCHAR(10) NOT NULL,      -- IN / OUT
  quantity        INT NOT NULL,
  movement_date   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reference_type  VARCHAR(30),
  reference_id    INT,
  FOREIGN KEY (item_id) REFERENCES items(item_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- (B) Boutique Tables (Sales side)
-- =========================

-- =========================
-- 11) Customers
-- =========================
CREATE TABLE customers (
  customer_id          INT AUTO_INCREMENT PRIMARY KEY,
  name                 VARCHAR(255) NOT NULL,
  contact_information  VARCHAR(255),
  address              TEXT,
  email                VARCHAR(255) UNIQUE
);

-- =========================
-- 12) Customer <-> User Accounts (N:M)
-- =========================
CREATE TABLE customer_user_accounts (
  customer_id INT NOT NULL,
  user_id     INT NOT NULL,
  PRIMARY KEY (customer_id, user_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES user_accounts(user_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);

-- =========================
-- 13) Stock Items (Boutique)  (uses same categories + warehouses)
-- =========================
CREATE TABLE stock_items (
  item_id        INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(255) NOT NULL,
  description    TEXT,
  unit_price     DECIMAL(10,2) NOT NULL,
  stock_quantity INT NOT NULL DEFAULT 0,
  import_date    DATE,
  category_id    INT,
  warehouse_id   INT,
  FOREIGN KEY (category_id) REFERENCES categories(category_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 14) Sales Orders (with branch_id + staff_id)
-- =========================
CREATE TABLE sales_orders (
  sales_order_id  INT AUTO_INCREMENT PRIMARY KEY,
  customer_id     INT,
  branch_id       INT NOT NULL,
  staff_id        INT,
  order_date      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status          VARCHAR(50) NOT NULL DEFAULT 'Pending',
  total_amount    DECIMAL(10,2) NOT NULL DEFAULT 0.00,

  FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION,

  FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
);

-- =========================
-- 15) Invoices (1:1 with SalesOrders)
-- =========================
CREATE TABLE invoices (
  invoice_id      INT AUTO_INCREMENT PRIMARY KEY,
  sales_order_id  INT UNIQUE,
  invoice_date    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount          DECIMAL(10,2) NOT NULL,
  tax             DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  payment_status  VARCHAR(50) NOT NULL DEFAULT 'Unpaid',
  FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);

-- =========================
-- 16) Sale Items
-- =========================
CREATE TABLE sale_items (
  sale_item_id    INT AUTO_INCREMENT PRIMARY KEY,
  sales_order_id  INT NOT NULL,
  item_id         INT NOT NULL, -- references stock_items
  quantity        INT NOT NULL,
  unit_price      DECIMAL(10,2) NOT NULL,
  discount        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES stock_items(item_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- 17) Returns
-- =========================
CREATE TABLE returns (
  return_id      INT AUTO_INCREMENT PRIMARY KEY,
  sales_order_id INT NOT NULL,
  item_id        INT NOT NULL, -- references stock_items
  return_date    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  quantity       INT NOT NULL,
  reason         TEXT,
  status         VARCHAR(50) NOT NULL DEFAULT 'Requested',
  FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES stock_items(item_id)
    ON UPDATE CASCADE
    ON DELETE NO ACTION
);

-- =========================
-- Insert Data: Branches
-- =========================
INSERT INTO branches (name, location, contact_person) VALUES
('Ramallah Branch', 'Ramallah', 'Saleh'),
('Nablus Branch', 'Nablus', 'Anwar');

-- =========================
-- Insert Data: Warehouses
-- =========================
INSERT INTO warehouses (branch_id, name, location, capacity) VALUES
(1, 'Main Warehouse', 'Ramallah', 1000),
(2, 'North Warehouse', 'Nablus', 700);

-- =========================
-- Insert Data: Managers
-- =========================
INSERT INTO managers (branch_id, name, role, email, phone_number) VALUES
(1, 'Saleh Manager', 'Branch Manager', 'saleh.manager@company.com', '0599001122'),
(2, 'Anwar Manager', 'Branch Manager', 'anwar.manager@company.com', '0599887766');

-- =========================
-- Insert Data: Staff
-- =========================
INSERT INTO staff (branch_id, manager_id, name, role, phone, email) VALUES
(1, 1, 'Saleh', 'Admin', '0599111111', 'saleh@company.com'),
(2, 2, 'Anwar', 'Admin', '0599222222', 'anwar@company.com');

-- =========================
-- Insert Data: User Accounts (ONLY 2 Admins)
-- =========================
INSERT INTO user_accounts (staff_id, username, password_hash, role) VALUES
(1, 'saleh', 'hash_saleh_123', 'Admin'),
(2, 'anwar', 'hash_anwar_123', 'Admin');

-- =========================
-- Insert Data: Customers
-- =========================
INSERT INTO customers (name, contact_information, address, email) VALUES
('Ahmad Ali', '0599001122', 'Ramallah', 'ahmad@example.com'),
('Sara Hasan', '0599887766', 'Nablus', 'sara@example.com'),
('Omar Khaled', '0566778899', 'Hebron', 'omar@example.com');

-- =========================
-- Insert Data: Link Customers <-> User Accounts (N:M)
-- (اختياري) ربط العملاء بالحسابات
-- =========================
INSERT INTO customer_user_accounts (customer_id, user_id) VALUES
(1, 1),
(2, 2);

-- =========================
-- Insert Data: Categories
-- =========================
INSERT INTO categories (name, description) VALUES
('Electronics', 'Electronic devices and accessories'),
('Clothing', 'Men and Women clothing'),
('Groceries', 'Daily grocery items');

-- =========================
-- Insert Data: Items (Original items table)
-- =========================
INSERT INTO items (name, unit_price, stock_quantity, category_id) VALUES
('Laptop', 1200.00, 0, 1),
('Smartphone', 800.00, 0, 1),
('T-Shirt', 25.00, 0, 2),
('Rice Bag', 10.00, 0, 3);

-- =========================
-- Insert Data: Purchase Orders
-- =========================
INSERT INTO purchase_orders (staff_id, order_date, total_amount, status) VALUES
(1, '2024-01-10', 2000.00, 'Completed'),
(2, '2024-02-05', 800.00, 'Pending');

-- =========================
-- Insert Data: Purchase Order Items (Ternary)
-- =========================
INSERT INTO purchase_order_items (purchase_order_id, item_id, warehouse_id, quantity, unit_price) VALUES
(1, 1, 1, 1, 1200.00),
(1, 2, 1, 1, 800.00),
(2, 2, 2, 1, 800.00);

-- =========================
-- Insert Data: Stock Movements
-- =========================
INSERT INTO stock_movements (item_id, warehouse_id, movement_type, quantity, movement_date, reference_type, reference_id) VALUES
(1, 1, 'IN', 1, NOW(), 'PurchaseOrder', 1),
(2, 1, 'IN', 1, NOW(), 'PurchaseOrder', 1),
(2, 1, 'OUT', 1, NOW(), 'Sale', 1001);

-- =========================
-- Insert Data: Stock Items (Boutique stock_items)
-- =========================
INSERT INTO stock_items (name, description, unit_price, stock_quantity, import_date, category_id, warehouse_id) VALUES
('Laptop', 'Dell Laptop i7', 1200.00, 20, '2024-01-10', 1, 1),
('Smartphone', 'Samsung Galaxy', 800.00, 35, '2024-02-05', 1, 1),
('T-Shirt', 'Cotton T-Shirt', 25.00, 100, '2024-03-01', 2, 2),
('Rice Bag', '5kg Rice Bag', 10.00, 200, '2024-03-15', 3, 2);

-- =========================
-- Insert Data: Sales Orders
-- =========================
INSERT INTO sales_orders (customer_id, branch_id, staff_id, status, total_amount) VALUES
(1, 1, 1, 'Completed', 2025.00),
(2, 2, 2, 'Pending', 825.00),
(3, 2, 2, 'Completed', 50.00);

-- =========================
-- Insert Data: Invoices
-- =========================
INSERT INTO invoices (sales_order_id, amount, tax, payment_status) VALUES
(1, 2025.00, 125.00, 'Paid'),
(2, 825.00, 25.00, 'Unpaid'),
(3, 50.00, 5.00, 'Paid');

-- =========================
-- Insert Data: Sale Items
-- =========================
INSERT INTO sale_items (sales_order_id, item_id, quantity, unit_price, discount) VALUES
(1, 1, 1, 1200.00, 0.00),
(1, 2, 1, 800.00, 50.00),
(2, 2, 1, 800.00, 0.00),
(2, 3, 1, 25.00, 0.00),
(3, 3, 2, 25.00, 0.00);

-- =========================
-- Insert Data: Returns
-- =========================
INSERT INTO returns (sales_order_id, item_id, quantity, reason, status) VALUES
(1, 2, 1, 'Defective item', 'Approved'),
(3, 3, 1, 'Wrong size', 'Requested');

-- =========================
-- Quick Check
-- =========================
SELECT * FROM user_accounts;
